---
sidebar_label: defaultArgs
---

# defaultArgs variable

#### Signature:

```typescript
defaultArgs: (options?: import("puppeteer-core/internal/puppeteer-core.js").BrowserLaunchArgumentOptions | undefined) => string[]
```
