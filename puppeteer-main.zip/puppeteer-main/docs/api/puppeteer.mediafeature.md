---
sidebar_label: MediaFeature
---

# MediaFeature interface

#### Signature:

```typescript
export interface MediaFeature
```

## Properties

| Property | Modifiers | Type   | Description | Default |
| -------- | --------- | ------ | ----------- | ------- |
| name     |           | string |             |         |
| value    |           | string |             |         |
