---
sidebar_label: DeviceRequestPrompt.cancel
---

# DeviceRequestPrompt.cancel() method

Cancel the prompt.

#### Signature:

```typescript
class DeviceRequestPrompt {
  cancel(): Promise<void>;
}
```

**Returns:**

Promise&lt;void&gt;
