---
sidebar_label: ElementHandle.asElement
---

# ElementHandle.asElement() method

#### Signature:

```typescript
class ElementHandle {
  asElement(): ElementHandle<ElementType>;
}
```

**Returns:**

[ElementHandle](./puppeteer.elementhandle.md)&lt;ElementType&gt;
