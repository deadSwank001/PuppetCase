---
sidebar_label: Product
---

# Product type

Supported products.

#### Signature:

```typescript
export type Product = 'chrome' | 'firefox';
```
