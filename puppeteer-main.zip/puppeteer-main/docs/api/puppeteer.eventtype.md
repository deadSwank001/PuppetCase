---
sidebar_label: EventType
---

# EventType type

#### Signature:

```typescript
export type EventType = string | symbol;
```
