---
sidebar_label: CDP_WEBSOCKET_ENDPOINT_REGEX
---

# CDP_WEBSOCKET_ENDPOINT_REGEX variable

#### Signature:

```typescript
CDP_WEBSOCKET_ENDPOINT_REGEX: RegExp;
```
