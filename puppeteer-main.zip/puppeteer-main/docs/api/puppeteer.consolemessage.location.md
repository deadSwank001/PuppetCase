---
sidebar_label: ConsoleMessage.location
---

# ConsoleMessage.location() method

The location of the console message.

#### Signature:

```typescript
class ConsoleMessage {
  location(): ConsoleMessageLocation;
}
```

**Returns:**

[ConsoleMessageLocation](./puppeteer.consolemessagelocation.md)
