---
sidebar_label: unregisterCustomQueryHandler
---

# unregisterCustomQueryHandler() function

> Warning: This API is now obsolete.
>
> Import [Puppeteer](./puppeteer.puppeteer.md) and use the static method [Puppeteer.unregisterCustomQueryHandler()](./puppeteer.puppeteer.unregistercustomqueryhandler.md)

#### Signature:

```typescript
export declare function unregisterCustomQueryHandler(name: string): void;
```

## Parameters

| Parameter | Type   | Description |
| --------- | ------ | ----------- |
| name      | string |             |

**Returns:**

void
