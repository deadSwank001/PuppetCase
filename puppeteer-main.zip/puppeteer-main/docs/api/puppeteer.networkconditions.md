---
sidebar_label: networkConditions
---

# networkConditions variable

> Warning: This API is now obsolete.
>
> Import [PredefinedNetworkConditions](./puppeteer.predefinednetworkconditions.md).

#### Signature:

```typescript
networkConditions: Readonly<{
  'Slow 3G': NetworkConditions;
  'Fast 3G': NetworkConditions;
}>;
```
