---
sidebar_label: trimCache
---

# trimCache variable

#### Signature:

```typescript
trimCache: () => Promise<void>;
```
