---
sidebar_label: Handler
---

# Handler type

#### Signature:

```typescript
export type Handler<T = unknown> = (event: T) => void;
```
