---
sidebar_label: Dialog.type
---

# Dialog.type() method

The type of the dialog.

#### Signature:

```typescript
class Dialog {
  type(): Protocol.Page.DialogType;
}
```

**Returns:**

Protocol.Page.DialogType
