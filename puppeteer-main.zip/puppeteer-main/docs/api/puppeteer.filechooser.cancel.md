---
sidebar_label: FileChooser.cancel
---

# FileChooser.cancel() method

Closes the file chooser without selecting any files.

#### Signature:

```typescript
class FileChooser {
  cancel(): void;
}
```

**Returns:**

void
