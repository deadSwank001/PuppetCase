---
sidebar_label: Point
---

# Point interface

#### Signature:

```typescript
export interface Point
```

## Properties

| Property | Modifiers | Type   | Description | Default |
| -------- | --------- | ------ | ----------- | ------- |
| x        |           | number |             |         |
| y        |           | number |             |         |
