---
sidebar_label: HTTPRequest.url
---

# HTTPRequest.url() method

The URL of the request

#### Signature:

```typescript
class HTTPRequest {
  url(): string;
}
```

**Returns:**

string
