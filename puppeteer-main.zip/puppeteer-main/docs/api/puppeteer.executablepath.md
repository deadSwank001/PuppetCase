---
sidebar_label: executablePath
---

# executablePath variable

#### Signature:

```typescript
executablePath: (
  channel?:
    | import('puppeteer-core/internal/puppeteer-core.js').ChromeReleaseChannel
    | undefined
) => string;
```
