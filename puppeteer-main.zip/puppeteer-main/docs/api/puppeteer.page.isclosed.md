---
sidebar_label: Page.isClosed
---

# Page.isClosed() method

Indicates that the page has been closed.

#### Signature:

```typescript
class Page {
  isClosed(): boolean;
}
```

**Returns:**

boolean
