---
sidebar_label: Page.target
---

# Page.target() method

A target this page was created from.

#### Signature:

```typescript
class Page {
  target(): Target;
}
```

**Returns:**

[Target](./puppeteer.target.md)
