---
sidebar_label: HTTPResponse.url
---

# HTTPResponse.url() method

The URL of the response.

#### Signature:

```typescript
class HTTPResponse {
  url(): string;
}
```

**Returns:**

string
