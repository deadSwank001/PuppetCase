---
sidebar_label: Connection.url
---

# Connection.url() method

#### Signature:

```typescript
class Connection {
  url(): string;
}
```

**Returns:**

string
