---
sidebar_label: PuppeteerErrors
---

# PuppeteerErrors interface

> Warning: This API is now obsolete.
>
> Do not use.

#### Signature:

```typescript
export interface PuppeteerErrors
```

## Properties

| Property      | Modifiers | Type                                                 | Description | Default |
| ------------- | --------- | ---------------------------------------------------- | ----------- | ------- |
| ProtocolError |           | typeof [ProtocolError](./puppeteer.protocolerror.md) |             |         |
| TimeoutError  |           | typeof [TimeoutError](./puppeteer.timeouterror.md)   |             |         |
