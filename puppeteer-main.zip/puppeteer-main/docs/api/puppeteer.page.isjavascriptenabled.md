---
sidebar_label: Page.isJavaScriptEnabled
---

# Page.isJavaScriptEnabled() method

`true` if the page has JavaScript enabled, `false` otherwise.

#### Signature:

```typescript
class Page {
  isJavaScriptEnabled(): boolean;
}
```

**Returns:**

boolean
