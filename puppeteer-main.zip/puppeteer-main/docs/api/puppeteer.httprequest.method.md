---
sidebar_label: HTTPRequest.method
---

# HTTPRequest.method() method

The method used (`GET`, `POST`, etc.)

#### Signature:

```typescript
class HTTPRequest {
  method(): string;
}
```

**Returns:**

string
