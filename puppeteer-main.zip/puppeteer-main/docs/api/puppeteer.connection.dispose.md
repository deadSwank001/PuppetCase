---
sidebar_label: Connection.dispose
---

# Connection.dispose() method

#### Signature:

```typescript
class Connection {
  dispose(): void;
}
```

**Returns:**

void
