---
sidebar_label: canDownload
---

# canDownload() function

#### Signature:

```typescript
export declare function canDownload(options: InstallOptions): Promise<boolean>;
```

## Parameters

| Parameter | Type                                           | Description |
| --------- | ---------------------------------------------- | ----------- |
| options   | [InstallOptions](./browsers.installoptions.md) |             |

**Returns:**

Promise&lt;boolean&gt;
