---
sidebar_label: CommonEventEmitter.listenerCount
---

# CommonEventEmitter.listenerCount() method

#### Signature:

```typescript
interface CommonEventEmitter {
  listenerCount(event: string): number;
}
```

## Parameters

| Parameter | Type   | Description |
| --------- | ------ | ----------- |
| event     | string |             |

**Returns:**

number
