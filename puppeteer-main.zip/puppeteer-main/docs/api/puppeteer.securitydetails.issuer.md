---
sidebar_label: SecurityDetails.issuer
---

# SecurityDetails.issuer() method

The name of the issuer of the certificate.

#### Signature:

```typescript
class SecurityDetails {
  issuer(): string;
}
```

**Returns:**

string
