---
sidebar_label: Target.url
---

# Target.url() method

#### Signature:

```typescript
class Target {
  url(): string;
}
```

**Returns:**

string
