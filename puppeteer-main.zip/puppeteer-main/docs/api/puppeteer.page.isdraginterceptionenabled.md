---
sidebar_label: Page.isDragInterceptionEnabled
---

# Page.isDragInterceptionEnabled() method

`true` if drag events are being intercepted, `false` otherwise.

#### Signature:

```typescript
class Page {
  isDragInterceptionEnabled(): boolean;
}
```

**Returns:**

boolean
