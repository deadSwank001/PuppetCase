---
sidebar_label: Page.getDefaultTimeout
---

# Page.getDefaultTimeout() method

Maximum time in milliseconds.

#### Signature:

```typescript
class Page {
  getDefaultTimeout(): number;
}
```

**Returns:**

number
