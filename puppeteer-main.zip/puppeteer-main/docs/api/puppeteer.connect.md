---
sidebar_label: connect
---

# connect variable

#### Signature:

```typescript
connect: (
  options: import('puppeteer-core/internal/puppeteer-core.js').ConnectOptions
) => Promise<import('puppeteer-core/internal/puppeteer-core.js').Browser>;
```
