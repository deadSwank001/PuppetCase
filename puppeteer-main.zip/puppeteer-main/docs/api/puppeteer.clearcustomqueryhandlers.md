---
sidebar_label: clearCustomQueryHandlers
---

# clearCustomQueryHandlers() function

> Warning: This API is now obsolete.
>
> Import [Puppeteer](./puppeteer.puppeteer.md) and use the static method [Puppeteer.clearCustomQueryHandlers()](./puppeteer.puppeteer.clearcustomqueryhandlers.md)

#### Signature:

```typescript
export declare function clearCustomQueryHandlers(): void;
```

**Returns:**

void
