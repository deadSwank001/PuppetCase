---
sidebar_label: PuppeteerLifeCycleEvent
---

# PuppeteerLifeCycleEvent type

#### Signature:

```typescript
export type PuppeteerLifeCycleEvent =
  | 'load'
  | 'domcontentloaded'
  | 'networkidle0'
  | 'networkidle2';
```
