---
sidebar_label: CDPSession.connection
---

# CDPSession.connection() method

#### Signature:

```typescript
class CDPSession {
  connection(): Connection | undefined;
}
```

**Returns:**

[Connection](./puppeteer.connection.md) \| undefined
