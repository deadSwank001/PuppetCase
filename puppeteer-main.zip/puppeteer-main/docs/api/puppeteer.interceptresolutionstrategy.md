---
sidebar_label: InterceptResolutionStrategy
---

# InterceptResolutionStrategy type

> Warning: This API is now obsolete.
>
> please use [InterceptResolutionAction](./puppeteer.interceptresolutionaction.md) instead.

#### Signature:

```typescript
export type InterceptResolutionStrategy = InterceptResolutionAction;
```

**References:** [InterceptResolutionAction](./puppeteer.interceptresolutionaction.md)
