---
sidebar_label: Frame.isDetached
---

# Frame.isDetached() method

Is`true` if the frame has been detached. Otherwise, `false`.

#### Signature:

```typescript
class Frame {
  isDetached(): boolean;
}
```

**Returns:**

boolean
