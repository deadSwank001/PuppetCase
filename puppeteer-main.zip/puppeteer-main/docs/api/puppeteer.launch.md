---
sidebar_label: launch
---

# launch variable

#### Signature:

```typescript
launch: (
  options?:
    | import('puppeteer-core/internal/puppeteer-core.js').PuppeteerLaunchOptions
    | undefined
) => Promise<import('puppeteer-core/internal/puppeteer-core.js').Browser>;
```
