---
sidebar_label: TargetFilterCallback
---

# TargetFilterCallback type

#### Signature:

```typescript
export type TargetFilterCallback = (
  target: Protocol.Target.TargetInfo
) => boolean;
```
