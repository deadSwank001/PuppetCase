---
sidebar_label: ChromeReleaseChannel
---

# ChromeReleaseChannel type

#### Signature:

```typescript
export type ChromeReleaseChannel =
  | 'chrome'
  | 'chrome-beta'
  | 'chrome-canary'
  | 'chrome-dev';
```
