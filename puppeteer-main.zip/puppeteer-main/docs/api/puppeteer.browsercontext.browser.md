---
sidebar_label: BrowserContext.browser
---

# BrowserContext.browser() method

The browser this browser context belongs to.

#### Signature:

```typescript
class BrowserContext {
  browser(): Browser;
}
```

**Returns:**

[Browser](./puppeteer.browser.md)
