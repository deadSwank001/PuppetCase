---
sidebar_label: Frame.url
---

# Frame.url() method

The frame's URL.

#### Signature:

```typescript
class Frame {
  url(): string;
}
```

**Returns:**

string
