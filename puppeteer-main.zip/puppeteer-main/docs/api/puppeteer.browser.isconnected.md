---
sidebar_label: Browser.isConnected
---

# Browser.isConnected() method

Indicates that the browser is connected.

#### Signature:

```typescript
class Browser {
  isConnected(): boolean;
}
```

**Returns:**

boolean
