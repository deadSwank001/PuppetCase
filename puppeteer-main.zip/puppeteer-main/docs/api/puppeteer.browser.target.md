---
sidebar_label: Browser.target
---

# Browser.target() method

The target associated with the browser.

#### Signature:

```typescript
class Browser {
  target(): Target;
}
```

**Returns:**

[Target](./puppeteer.target.md)
